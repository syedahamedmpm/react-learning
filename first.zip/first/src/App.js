import React from 'react';
import Employee from './Employee'
class App extends React.Component{

render(){
return (
<div>
<FirstChild></FirstChild>
<SecondChild></SecondChild>
</div>
)
}

}
class FirstChild extends React.Component{

render(){
return (
<h1>Syed Ahamed Kather Mohaideen</h1>
)
}

}
class SecondChild extends React.Component{
	render(){
		return(
		<div>
		<h1>Second Child</h1>
		<ThirdChild></ThirdChild>
		</div>
		)
	}
}
class ThirdChild extends React.Component{
	render(){
		return(
		<div>
		<h1>Third Child</h1>
		<Employee name='Syed Ahamed' id={1001}></Employee>
		</div>
		)
	}
}

export default App;
