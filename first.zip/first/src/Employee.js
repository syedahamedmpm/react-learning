import React from 'react';
import Skills from './Skills';

// function Employee(props){
	// return(
	// <div>
	// <h1>Hello Mr.{props.name}</h1>
	// <h1>Your Id Is {props.id}</h1>
// </div>
// )
// }

class Employee extends React.Component{
render(){
return(
<div>
<h1>Hi Mr.{this.props.name}</h1>
<h1>Your Id{this.props.id}</h1>
<Skills skills="React Developer"></Skills>
</div>
)
}	
}
export default Employee;
