import React from 'react';

function FullDetails(props){
return(
<div>
<h1 style={{color : "Blue"}}>Location : {props.location}</h1>
</div>
 )
}


export default FullDetails;
