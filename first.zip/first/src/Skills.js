import React from 'react';
import FullDetails from './FullDetails'

function Skills(props){
return(
<div>
<h1 style={{color : "Red"}}>My Skill is {props.skills}</h1>
<FullDetails location="Delhi"></FullDetails>
</div>
 )
}


export default Skills;
